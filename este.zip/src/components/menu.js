export const menuItems = [
    {
        id: 1,
        label: "menuitems.menu.text",
        isTitle: true
    },
    {
        id: 2,
        label: 'menuitems.dashboard.text',
        icon: 'ri-dashboard-line',
        link: '/'
    },
    {
        id: 3,
        label: 'menuitems.registers.text',
        icon: 'ri-store-2-line',
        subItems: [            
            {
                id: 31,
                label: 'menuitems.registers.list.customers',
                icon: 'ri-team-fill',
                link: '/cadastros/pessoas'
            },
            {
                id: 32,
                label: 'menuitems.registers.list.companies',
                icon: 'ri-building-fill',
                link: '/cadastros/empresas'
            },
            {
                id: 33,
                label: 'menuitems.registers.list.products',
                icon: 'ri-archive-fill',
                link: '/cadastros/produtos'
            },
            {
                id: 34,
                label: 'menuitems.registers.list.stocklocation',
                icon: 'ri-stack-fill',
                link: '/cadastros/localestoque'
            },
        ]
    },
    {
        id: 4,
        label: 'menuitems.finance.text',
        icon: 'ri-exchange-funds-line',
        subItems: [
            {
                id: 41,
                label: 'menuitems.finance.list.orders',
                link: '/financeiro/pedidos'
            },
            {
                id: 42,
                label: 'menuitems.finance.list.banco',
                link: '/financeiro/bancos'
            },
            {
                id: 43,
                label: 'menuitems.finance.list.agencia',
                link: '/financeiro/agenciaBanc'
            }
        ]
    },
    {
        id: 5,
        label: 'menuitems.parameters.text',
        icon: 'ri-global-line',
        subItems: [
            {
                id: 51,
                label: 'menuitems.parameters.list.typesofmovement',
                link: '/parametros/tiposmovimento',
            },
            {
                id: 52,
                label: 'menuitems.parameters.list.paymenttypes',
                link: '/parametros/tipospagamento',
            },
            {
                id: 53,
                label: 'menuitems.parameters.list.costcenter',
                link: '/parametros/centrocusto',
            },
            {
                id: 54,
                label: 'menuitems.parameters.list.resultcenter',
                link: '/parametros/centroresultado',
            },
            {
                id: 55,
                label: 'menuitems.parameters.list.historiesdefault',
                link: '/parametros/historicopadrao',
            },
            {
                id: 56,
                label: 'menuitems.parameters.list.unidademed',
                link: '/parametros/unidademed',
            },
            {
                id: 57,
                label: 'menuitems.parameters.list.grupos',
                link: '/parametros/grupos',
            },
            
            
        ]
    },
    {
        id: 6,
        label: 'menuitems.users.text',
        icon: 'ri-account-circle-line',
        subItems: [            
            {
                id: 61,
                label: 'menuitems.users.list.insert',
                link: '/register'
            },
            {
                id: 62,
                label: 'menuitems.users.list.changepassword',
                link: '/forgot-password'
            },
            {
                id: 63,
                label: 'menuitems.users.list.list',
                link: '/userGetAll'
            }
        ]
    },
]