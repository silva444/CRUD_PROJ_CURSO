export const indicadorEstoque = [
  { value: '0', text: 'Estoque de propriedade do informante e em posse de terceiros' },
  { value: '1', text: 'Estoque de propriedade de terceiros e em posse do informante' },
  { value: '2', text: 'Estoque de propriedade do informante e em seu poder' },
];