<template>
  <footer class="footer">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6">
          2021 © EasyIndustria Web 1.0.
        </div>
        <div class="col-sm-6">
          <div class="text-sm-right d-none d-sm-block">
            SiD Soluções
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>