import axios from 'axios'

let baseApiUrl = 'https://app.sidsolucoes.com.br/api/';

const httpUF = axios.create({
  baseURL: baseApiUrl,
  headers: {    
    ContentType: 'text/html; charset=UTF-8',
     Accept: 'text/html; charset=UTF-8',
    Method: 'POST',
    Credential: true,
  }
});

export { httpUF }