<script>
import appConfig from "@/app.config";
import {http} from "../../../helpers/easyindustriaapi/config";
import {
  authEasyMethods,
  notificationMethods
} from "@/state/helpers";
import Layout from "../../layouts/main";
import PageHeader from "@/components/page-header";
import Detail from "./detail";

console.clear();

export default {
  page: {
    title: "Empresas",
    meta: [{ name: "description", content: appConfig.description }]
  },
  components: { Layout, PageHeader, Detail },
  data() {
    return {
        currentUser: null,
        currentEmpresa: null,
        empresas: [],
        titleBody: "Listagem das Empresas",
        items: [
            {
            text: "Dashboard",
            href: "/",
            },
            {
            text: "Empresas",
            href: "/empresas",
            active: true,
            }
        ],
        totalRows: 1,
        currentPage: 1,
        perPage: 10,
        pageOptions: [10, 25, 50, 100],
        filter: null,
        filterOn: [],
        sortBy: "id",
        sortDesc: false,
        fields: [
          { label: "ID", key: "id", sortable: true, tdClass: 'text-right', thClass: 'text-center' },
          { label: "Apelido", key: "apelido", sortable: true, thClass: 'text-center' },
          { label: "CNPJ", key: "cnpj", sortable: true, tdClass: 'text-right', thClass: 'text-center' },
          { label: "I. E.", key: "ie", sortable: false, tdClass: 'text-right', thClass: 'text-center' },
          { label: 'Última NF-e', key: 'ultianfe', sortable: false, tdClass: 'text-right', thClass: 'text-center' },
          { label: "Ações", key: "acoes", sortable: false, tdClass: 'text-center', thClass: 'text-center' }
        ],
        editando: false,
    }
  },
  created() {
    this.currentUser    = JSON.parse(localStorage.getItem('user'));
    this.currentEmpresa = JSON.parse(localStorage.getItem('currentEmpresa'));
    this.notification.clear;
  },
  computed: {
    /**
     * Total no. of records
     */
    rows() {
      return this.empresas.length;
    },
    notification() {
      return this.$store ? this.$store.state.notification : null;
    },
    clonefoot() {
      return (this.empresas.length > 10) ? true : false;
    },
  },
  mounted() {
    this.getData();

    // Set the initial number of items
    this.totalRows = this.items.length;
  },
  methods: {
    ...authEasyMethods,
    ...notificationMethods,
    /**
     * Search the table data with search input
     */
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
      this.currentPage = 1;
    },
    onLoader() {
      if (document.getElementById("preloader").style.display === "none")
      {
        document.getElementById("preloader").style.display = "block";
        document.getElementById("status").style.display = "block";
      }
    },
    offLoader() {
      if (document.getElementById("preloader").style.display === "block")
      {
        setTimeout(function () {
          document.getElementById("preloader").style.display = "none";
          document.getElementById("status").style.display = "none";
        }, 2500);
      }
    },
    async getData() {
        this.onLoader();
        try {
          await http.get('empresa/list/'+this.currentUser.id)
          .then(res => {
            this.empresas = res.data;
          })
          .finally(() => {
            setTimeout(() => this.offLoader(), 3000);
          });
        } catch (error) {
          this.offLoader();
          if (error.response && error.response.status === 403) {
            this.error('Usuário não tem permissão!');
          }
        }
    },
    setEmpresaDetail(empresa) {
      this.currentEmpresa = empresa;
    },
  },
}
</script>

<template>
  <Layout>
    <PageHeader :title="titleBody" :items="items" />
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <b-alert
              :variant="notification.type"
              class="mt-3"
              v-if="notification.message"
              show
              dismissible
            >{{notification.message}}</b-alert>
            <div class="row">
                <div class="col-sm-12 col-md-6">
                </div>
                <div class="col-sm-12 col-md-6 text-md-right">
                  <button v-if="editando" class="btn btn-light" @click="voltar()">Voltar</button>
                </div>
            </div>
          </div>
          <div class="card-body">
            <Edit v-if="editando"
             @status="editando"
             @voltar="voltar"
             @alterarEmpresa="alterar"
             @newTitle="changeHomeTitle"
             :oldEmpresa="currentEmpresa"
             :currentEmpresa="currentEmpresa"
            />
          </div>
          <div class="card-body" v-if="!editando">
            <div class="row mt-4">
              <div class="col-sm-12 col-md-6">
                <div id="tickets-table_length" class="dataTables_length">
                  <label class="d-inline-flex align-items-center">
                    Exibir&nbsp;
                    <b-form-select v-model="perPage" size="sm" :options="pageOptions"></b-form-select>&nbsp;registros
                  </label>
                </div>
              </div>
              <!-- Search -->
              <div class="col-sm-12 col-md-6">
                <div id="tickets-table_filter" class="dataTables_filter text-md-right">
                  <label class="d-inline-flex align-items-center">
                    Pesquisar:
                    <b-form-input
                      v-model="filter"
                      type="search"
                      placeholder="Pesquisar..."
                      class="form-control form-control-sm ml-2"
                    ></b-form-input>
                  </label>
                </div>
              </div>
              <!-- End search -->
            </div>
            <!-- Table -->
            <div v-if="!editando" class="table-responsive mb-0">
              <b-table
               :items="empresas"
               :fields="fields"
               responsive="sm"
               :per-page="perPage"
               :current-page="currentPage"
               :sort-by.sync="sortBy"
               :sort-desc.sync="sortDesc"
               :filter="filter"
               :filter-included-fields="filterOn"
               @filtered="onFiltered"
               :hover=true
               :foot-clone=clonefoot
              >
                <template #cell(acoes)="row">
                  <!-- `data.value` is the value after formatted by the Formatter -->
                  <b-dropdown v-bind:id="'dropdown-'+ row.item.id" class="m-md-2">
                  <template #button-content>
                      <i data-v-6289eca4="" class="bx ri-menu-line"></i>
                  </template>
                  <b-dropdown-item v-b-modal.modal-empresa @click="setEmpresaDetail(row.item)"><i class="bx ri-file-search-line"></i> Visualizar</b-dropdown-item>
                  </b-dropdown>
                </template>
              </b-table>
            </div>
            <!-- End Table -->
            <!-- START Modal Empresa -->
            <b-modal
              hide-footer
              id="modal-empresa"
              size="xl"
              :title="currentEmpresa.apelido"
              title-class="font-18"
            >
              <Detail :empresa="currentEmpresa" />
            </b-modal>
            <!-- END Modal Empresa -->
        </div>
        </div>
      </div>
    </div>
  </Layout>
</template>