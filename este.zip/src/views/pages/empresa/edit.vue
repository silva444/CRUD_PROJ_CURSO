<script>
import appConfig from "@/app.config";
import Multiselect from "vue-multiselect";

export default {
  page: {
    title: "Alterar Empresa",
    meta: [{ name: "description", content: appConfig.description }]
  },
  props: {
    currentEmpresa: {},
    oldEmpresa: { type: Object },
  },
  components: {
    Multiselect,
  },
  data() {
    return {
      editando: false,
      empresa: {},
    }
  },
  mounted() {
    this.empresa = this.oldEmpresa;
    this.setNewTitle();
  },
  methods: {
    setNewTitle () {
      this.$emit("newTitle", 'Alterar Empresa ' + this.empresa.id);
    },
    voltar () {
      this.inserindo = !this.inserindo;
      this.$emit('status', this.inserindo);
      this.$emit('voltar');
    },
    setAlterar () {
      this.inserindo = !this.inserindo;
      this.$emit("alterarEmpresa", this.empresa);
    },
  },
}
</script>