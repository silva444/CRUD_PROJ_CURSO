<script>
import moment from 'moment';
import appConfig from "@/app.config";
import { http } from '@/helpers/easyindustriaapi/config';
import Layout from "@/views/layouts/main";
import PageHeader from "@/components/page-header";
import List from "./list";
import EntradaBalanca from "./entrada-balanca";
import InsertCompra from "./insert-compra";
import EditCompra from "./edit-compra";

export default {
  page: {
    title: "Pedidos",
    meta: [{name: "description", content: appConfig.description}]
  },
  components: { Layout, PageHeader, List, EntradaBalanca, InsertCompra, EditCompra },
  data() {
    return {
      loader: {
        get: false
      },
      currentUser: null,
      currentEmpresa: null,
      submitted: false,
      listPedidos: [],
      currentPedido: {
        id: null,
        pessoa_id: null,
        nnf: null,
        tpnf: 0,
        tipopgto_id: null,
        qtde_parcelas: 1,
        historicopdr_id: null,
        tpmovimento_id: null,
        loc_id: null,
      },
      searchCompras: {},
      titleBody: "Listagem dos Pedidos",
      items: [
        {
          text: "Dashboard",
          href: "/",
        },
        {
          text: "Pedidos",
          href: "/financeiro/pedidos",
          active: true,
        }
      ],
      inserindo: false,
      editando: false,
      hideSearches: false,
      insertingCompra: false,
      editingCompra: false,
      entradaBalancaVisible: false,
      listTabelas: undefined,
    }
  },
  computed: {
    isHide() {
      return (!this.inserindo && !this.editando);
    },
  },
  created() {
    this.currentUser    = JSON.parse(localStorage.getItem('user'));
    this.currentEmpresa = JSON.parse(localStorage.getItem('currentEmpresa'));
    this.searchCompras.fromData = moment().startOf('month').format('YYYY-MM-DD HH:mm:ss');
    this.searchCompras.toData = moment().endOf('month').format('YYYY-MM-DD HH:mm:ss');
    this.currentPedido.dh_saient = this.searchCompras.toData;
    this.currentPedido.dataemissao = this.searchCompras.toData;
  },
  mounted() {
    this.getData();
  },
  methods: {
    makeToast(variant = null, message = 'Error generic') {
      this.counter++;
      this.$bvToast.toast(message, {
        title: `Notificação`,
        toaster: 'b-toaster-bottom-right',
        variant: variant,
        solid: true,
        appendToast: true
      });
    },
    changeHomeTitle(newTitle) {
      this.titleBody = newTitle;
    },
    back() {
      this.changeHomeTitle('Listagem dos Pedidos');
      this.inserindo     = false;
      this.insertingCompra  = false;
      this.editingCompra = false
      this.entradaBalancaVisible = false;
      this.editando      = false;
    },
    onLoader() {
      if (document.getElementById("preloader").style.display === "none")
      {
        document.getElementById("preloader").style.display = "block";
        document.getElementById("status").style.display = "block";
      }
    },
    offLoader() {
      if (document.getElementById("preloader").style.display === "block")
      {
        setTimeout(function () {
          document.getElementById("preloader").style.display = "none";
          document.getElementById("status").style.display = "none";
        }, 2500);
      }
    },
    searchInputs() {
      this.hideSearches = !this.hideSearches;
    },
    clearNewPedido() {
      let today = new Date();
      this.currentPedido.id              = null;
      this.currentPedido.pessoa_id       = null;
      this.currentPedido.nnf             = null;
      this.currentPedido.tpnf            = 0;
      this.currentPedido.tipopgto_id     = null;
      this.currentPedido.qtde_parcelas   = 1;
      this.currentPedido.historicopdr_id = null;
      this.currentPedido.tpmovimento_id  = null;
      this.currentPedido.loc_id          = null;
      this.currentPedido.dh_saient       = moment(today).format('yyyy-MM-ddThh:mm');
      this.currentPedido.dataemissao     = moment(today).format('yyyy-MM-ddThh:mm');
    },
    async getData() {
      this.loader.get = true;

      try {
        let toParams = {
          fromNNf: this.searchCompras.fromNNf,
          toNNf: this.searchCompras.toNNf,
          fromData: (this.searchCompras.fromData) ? moment(this.searchCompras.fromData).format('yyyy-MM-DD HH:mm:ss') : null,
          toData: (this.searchCompras.toData) ? moment(this.searchCompras.toData).format('yyyy-MM-DD HH:mm:ss') : null,
          destinatario: this.searchCompras.destinatario
        };
        
        let response = await http.get('/pedido/list?empresa_id=' + this.currentEmpresa.id, {
          params: toParams
        });

        if (response.status === 200) {
          this.listPedidos = response.data;
          setTimeout(() => {
            this.offLoader();
          }, 2000);
          this.searchInputs();
        }
      } catch (error) {
        let messageErro = error.response.data;

        switch (error.response.status) {
          case 406:
            this.makeToast('danger', 'Erro 406: ' + (messageErro.nnf) ? messageErro.pessoa_id : messageErro.tipo_id);
            this.offLoader();
            break;
          case 404:
            this.makeToast('danger', 'Erro 404: endpoint não encontrado ou servidor fora do ar');
            this.offLoader();
            break;

          default:
            this.makeToast('danger', error.message);
            this.offLoader();
            break;
        }
        this.loader.get = false;
      }

      this.loader.get = false;
    },
    incluirEntradaBalanca() {
      this.entradaBalancaVisible = !this.entradaBalancaVisible;
    },
    async insertCompra() {
      this.onLoader();
      await this.getDadosGerais();
      this.clearNewPedido();
      this.inserindo = !this.inserindo;
      this.insertingCompra = !this.insertingCompra;
      this.offLoader();
    },
    async editCompra(pedido) {
      this.onLoader();
      this.currentPedido = pedido;
      await this.getDadosGerais();
      this.editando = !this.editando;
      this.editingCompra = !this.editingCompra;
      this.offLoader();
    },
    edit() {
      this.editando = !this.editando;
    },
    async entradaBalanca() {
      this.onLoader();
      await this.getDadosGerais();
      this.inserindo = !this.inserindo;
      this.entradaBalancaVisible = !this.entradaBalancaVisible;
      this.offLoader();
    },
    async getDadosGerais() {
      try {
        if (this.listTabelas == undefined) {
          await http.get('/tabelas/dadoscompras?empresa_id=' + this.currentEmpresa.id)
            .then(res => {
              this.listTabelas = res.data ;
            })
            .finally(() => {
            });
        }
      } catch (error) {
        if (error.response && error.response.status === 403) {
          this.error('Usuário não tem permissão!');
        }
      }
    },
    async doPost() {
      let response = await http.post('/pedido/?empresa_id='+this.currentEmpresa.id, this.currentPedido).catch((error) => {
        this.error(error.response);
        this.makeToast('danger', error.response);
      });

      if (response.status === 200) {
        this.getData();
        this.back();
        this.offLoader();
        this.makeToast('success', 'Pedido incluído');
      }
    },
    async doPut() {
      let response = await http.put('/pedido/?empresa_id='+this.currentEmpresa.id, this.currentPedido).catch((error) => {
        this.error(error.response);
        this.makeToast('danger', error.response);
      });

      if (response.status === 200) {
        this.getData();
        this.back();
        this.offLoader();
        this.makeToast('success', 'Pedido alterado');
      }
    },
  },
}
</script>

<template>
  <Layout>
    <PageHeader :title="titleBody" :items="items" />
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-12 col-md-6">
                <button v-if="isHide" class="btn btn-light" @click="searchInputs()">
                  <span class="fa-sm fa" :class="(hideSearches) ? 'fa-chevron-up' : 'fa-chevron-down'"></span> Busca
                  avançada
                </button>
              </div>
              <div class="col-sm-12 col-md-6 text-md-right">
                <button v-if="isHide" class="btn btn-primary mr-2" @click="entradaBalanca()">+ Incluir Pesagem</button>
                <button v-if="isHide" class="btn btn-success mr-2" @click="insertCompra()">+ Incluir Compra</button>
                <button v-if="isHide" class="btn btn-success mr-2" @click="importarXML()">+ Importar XML</button>
                <button v-if="!isHide" class="btn btn-secondary" @click="back()">Voltar</button>
              </div>
            </div>
          </div>
          <div class="card-body" v-if="hideSearches">
            <!-- Start Card -->
            <div class="card border border-primary">
              <div class="card-body">
                <h4 class="card-title">Filtros</h4>
                <p class="card-title-desc">Use esses campos para filtrar os registros</p>
                <form class="needs-validation" name="search">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group">
                        <label for="searchCompras-status">Nº Documento</label>
                        <div class="row">
                          <div class="col-md-6">
                            <input id="searchCompras-fromNNf" v-model="searchCompras.fromNNf" type="number"
                              class="form-control" placeholder="Nº NF" />
                          </div>
                          <div class="col-md-6">
                            <input id="searchCompras-toNNf" v-model="searchCompras.toNNf" type="number"
                              class="form-control" placeholder="Nº NF" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="searchCompras-fromData">Data saída</label>
                        <div class="row">
                          <div class="col-md-6">
                            <input id="searchCompras-fromData" v-model="searchCompras.fromData" type="datetime-local"
                              class="form-control" placeholder="dd/mm/aaaa hh:mm"/>
                          </div>
                          <div class="col-md-6">
                            <input id="searchCompras-toData" v-model="searchCompras.toData" type="datetime-local"
                              class="form-control" placeholder="dd/mm/aaaa hh:mm"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label>Fornecedor</label>
                        <input id="searchCompras-destinatario" v-model="searchCompras.destinatario" type="text"
                          class="form-control" placeholder="Nome do Fornecedor" />
                      </div>
                    </div>
                  </div>
                  <button @click="getData" class="btn btn-primary" type="button">OK</button>
                </form>
              </div>
            </div>
            <!-- End Card -->
          </div>
          <div class="card-body">
            <EntradaBalanca :newCompra="currentPedido" :oldItems="items" v-if="entradaBalancaVisible"
              :listTabelas="listTabelas" />
            <InsertCompra v-if="insertingCompra" :newPedido="currentPedido" :oldItems="items"
              :listTabelas="listTabelas" @newTitle="changeHomeTitle" :currentEmpresa="currentEmpresa"
              :onLoader="onLoader" :offLoader="offLoader" @doPost="doPost" />
            <EditCompra v-if="editingCompra" :currentPedido="currentPedido" :oldItems="items"
              :listTabelas="listTabelas" @newTitle="changeHomeTitle" :currentEmpresa="currentEmpresa"
              :onLoader="onLoader" :offLoader="offLoader" @doPut="doPut" />
            <List v-if="isHide" :currentEmpresa="currentEmpresa" :listPedidos="listPedidos" :isBusy="loader.get" @editCompra="editCompra" />
          </div>
        </div>
      </div>
    </div>
  </Layout>
</template>