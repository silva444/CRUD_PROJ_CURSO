<script>
import {listTPag} from "@/components/defaults/tpag";

export default {
  props: {
    oldTipoPagamento: { type: Object, required: true }
  },
  data() {
    return {
      loader: {get: false},
      titleBody: 'Alterar Forma de Pagamento',
      tipoPagamento: {},
      listTipoDFe: [],
    }
  },
  mounted() {
    this.setNewTitle();
    this.tipoPagamento = this.oldTipoPagamento;
    this.listTipoDFe = listTPag;
  },
  methods: {
    setNewTitle() {
      this.$emit('newTitle', this.titleBody);
    },
    setPut() {
      this.$emit('doPut', this.tipoPagamento);
    },
  },
}
</script>

<template>
<div class="card">
  <div class="card-body">
    <i v-if="loader.get" class="fa fa-spinner fa-5x fa-spin text-success text-center"></i>
    <form id="form-tipo-pagamento" role="form" class="form-horizontal">
      <b-card no-body class="mb-1">
        <b-card-body>
          <div class="form-row form-group" role="group">
            <div class="col-sm-12 col-md-3">
              <div class="form-group">
                <label for="tipo_pagamento_id" class="col-form-label">Código</label>
                <div class="col">
                  <input disabled v-model="tipoPagamento.id" class="form-control text-right" type="text" placeholder="Gerado pelo sistema" id="tipo_pagamento_id">
                </div>
              </div>
            </div>
          </div>
          <div class="form-row form-group" role="group">
            <div class="col-sm-12 col-md-8">
              <div class="form-group">
                <label for="tipo_pagamento_tiponome" class="col-form-label">Nome da Forma de Pagamento</label>
                  <div class="col">
                    <input v-model="tipoPagamento.tiponome" class="form-control" type="text" placeholder="Dinheiro, Cartão, Vale..." id="tipo_pagamento_tiponome">
                  </div>
              </div>
            </div>
          </div>
          <div class="form-row form-group" role="group">
            <div class="col-sm-12 col-md-4">
              <div class="form-group">
                <div class="col">
                    <b-form-checkbox
                     id="tipo-pagamento-touch"
                     v-model="tipoPagamento.touch"
                     name="touch"
                     value="1"
                     unchecked-value="0"
                    >
                        Mostrar no Touch
                    </b-form-checkbox>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="form-group">
                <div class="col">
                  <b-form-checkbox
                   id="tipo-pagamento-adquerente"
                   v-model="tipoPagamento.adquerente"
                   name="adquerente"
                   value="true"
                   unchecked-value="false"
                  >
                      Com Adquirente
                  </b-form-checkbox>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-2">
              <div class="form-group">
                <div class="col">
                  <label>Tecla Atalho</label>
                  <b-form-input
                   id="tipo-pagamento-teclaatalho"
                   v-model="tipoPagamento.teclaatalho"
                   name="teclaatalho"
                  >
                  </b-form-input>
                </div>
              </div>
            </div>
          </div>
          <div class="form-row form-group" role="group">
            <div class="col-sm-12">
              <b-form-group label="Formas de Pagamento DF-e" v-slot="{ ariaDescribedby }">
                <b-form-radio-group
                 id="tipo-pagamento-tpag"
                 v-model="tipoPagamento.tpag"
                 :options="listTipoDFe"
                 :aria-describedby="ariaDescribedby"
                 name="tpag"
                >
                </b-form-radio-group>
              </b-form-group>
            </div>
          </div>
        </b-card-body>
      </b-card>
    </form>
  </div>
  <div class="card-body">
    <div class="col-md-12 mt-10">
      <button class="btn btn-light"
       @click="setPut">Gravar</button>
    </div>
  </div>
</div>
</template>

<style>
.custom-control.custom-control-inline.custom-radio {
    margin-top: 12px;
    min-width: 300px;
}
</style>