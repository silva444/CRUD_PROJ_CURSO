<script>
import appConfig from "@/app.config";
import { http } from '@/helpers/easyindustriaapi/config';
import Layout from "@/views/layouts/main";
import PageHeader from "@/components/page-header";
import List from "./list";
import Insert from "./insert";
import Edit from "./edit";

export default {
  page: {
      title: 'Centros de Resultado',
      meta: [{ name: 'description', content: appConfig.description }],
  },
  components: { Layout, PageHeader, List, Insert, Edit },
  data() {
    return {
      newWonerID: 0,
      currentCentroResultado: {},
      centrosResultado: [],
      inserindo: false,
      editando: false,
      titleBody: 'Centros de Resultado',
      items: [
        {
        text: "Dashboard",
        href: "/",
        },
        {
        text: "Parâmetros",
        href: "/",
        active: true,
        },
        {
        text: "Centros de Resultado",
        href: "/parametros/centroresultado",
        active: true,
        }
      ],

    }
  },
  computed: {
    isHide() {
      return (!this.inserindo && !this.editando);
    },
  },
  created() {
    this.currentUser    = JSON.parse(localStorage.getItem('user'));
    this.currentEmpresa = JSON.parse(localStorage.getItem('currentEmpresa'));
  },
  mounted() {
    this.getData();
  },
  methods: {
    makeToast(variant = null, message = 'Error generic') {
      this.counter++;
      this.$bvToast.toast(message, {
        title: `Notificação`,
        toaster: 'b-toaster-bottom-right',
        variant: variant,
        solid: true,
        appendToast: true
      });
    },
    changeHomeTitle(newTitle) {
      this.titleBody = newTitle;
    },
    back() {
      this.inserindo = false;
      this.editando = false;
    },
    onLoader() {
      if (document.getElementById("preloader").style.display === "none")
      {
        document.getElementById("preloader").style.display = "block";
        document.getElementById("status").style.display = "block";
      }
    },
    offLoader() {
      if (document.getElementById("preloader").style.display === "block")
      {
        setTimeout(function () {
          document.getElementById("preloader").style.display = "none";
          document.getElementById("status").style.display = "none";
        }, 2500);
      }
    },
    insert(wonerID) {
      this.newWonerID = wonerID;
      this.inserindo = !this.inserindo;
    },
    edit(centroResultado) {
      this.currentCentroResultado = centroResultado;
      this.editando = !this.editando;
    },
    async getData() {
      this.onLoader();

      try {
        let response = await http.get('/centroresultado?empresa_id=' + this.currentEmpresa.id);

        if (response.status === 200) {
          this.centrosResultado = response.data;
          this.offLoader();
        }
      } catch (error) {
        let messageErro = error.response.data;

        switch (error.response.status) {
          case 406:
            this.makeToast('danger', 'Erro 406: ' + (messageErro.tipo) ? messageErro.tiponome : messageErro.tpag);
            this.offLoader();
            break;
          case 404:
            this.makeToast('danger', 'Erro 404: endpoint não encontrado ou servidor fora do ar');
            this.offLoader();
            break;
        
          default:
            this.makeToast('danger', error.message);
            this.offLoader();
            break;
        }
      }
    },
    async doPost(newcentroResultado) {
      newcentroResultado.empresa_id = this.currentEmpresa.id;
      let response = await http.post('/centroresultado?empresa_id='+this.currentEmpresa.id, newcentroResultado)
        .catch((error) => {
            this.makeToast('danger', error.response);
            this.offLoader();
        });

      if (response.status === 200) {
        this.getData();
        this.makeToast('success', 'Registro incluído');
        this.back();
      }
    },
    async doPut(centroResultado) {
      this.onLoader();
      centroResultado.empresa_id = this.currentEmpresa.id;
      let response = await http.put('/centroresultado/'+centroResultado.id+'?empresa_id='+this.currentEmpresa.id, centroResultado)
        .catch((error) => {
            this.offLoader();
            this.makeToast('danger', error.response);
        });

      if (response.status === 200) {
        this.getData();
        this.back();
        this.makeToast('success', 'Registro alterado');
      }
    },
    async doDelete(centroResultado) {
      this.onLoader();
      centroResultado.empresa_id = this.currentEmpresa.id;
      let response = await http.delete('/centroresultado/'+centroResultado.id+'?empresa_id='+this.currentEmpresa.id, centroResultado)
        .catch((error) => {
            this.makeToast('danger', error.response);
            this.offLoader();
        });

      if (response.status === 200) {
        this.getData();
        this.back();
        this.makeToast('warning', 'Registro excluído');
      }
    },
  },
}
</script>

<template>
<Layout>
  <PageHeader :title="titleBody" :items="items" />
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <!-- Start Bar Buttons -->
        <div class="card-body">
          <div class="row">
            <div class="col-sm-12 col-md-6"></div>
            <div class="col-sm-12 col-md-6 text-md-right">
              <button @click="insert(0)" v-if="isHide" type="button" class="btn btn-success">+ Incluir Centro de Resultado</button>
              <button @click="back()" v-if="!isHide" class="btn btn-secondary">Voltar</button>
            </div>
          </div>
        </div>
        <!-- End Bar Buttons -->
        <div class="card-body" v-if="!isHide">
          <Insert v-if="inserindo"
           :empresa="currentEmpresa"
           :wonerID="newWonerID"
           @newTitle="changeHomeTitle"
           @doPost="doPost"
          />
          <Edit v-if="editando"
           :empresa="currentEmpresa"
           :oldCentroResultado="currentCentroResultado"
           @newTitle="changeHomeTitle"
           @doPut="doPut"
          />
        </div>
        <List v-if="isHide"
         :currentEmpresa="currentEmpresa"
         :listCentrosResultado="centrosResultado"
         :hide="isHide"
         @newTitle="changeHomeTitle"
         @edit="edit"
         @doDelete="doDelete"
        />
      </div>
    </div>
  </div>
</Layout>
</template>