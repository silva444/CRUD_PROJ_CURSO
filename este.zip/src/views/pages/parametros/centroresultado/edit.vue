<script>
export default {
    props: {
      empresa: { type: Object, required: true },
      oldCentroResultado: { type: Object, required: true },
    },
  data() {
    return {
      titleBody: 'Alterar Centro de Resultado',
      centroResultado: {
        id: -1,
        woner_id: 0,
        conta: null,
        indetificao: null,
        status: true,
      },
    }
  },
  created() {},
  mounted() {
    this.centroResultado = this.oldCentroResultado;
    this.$emit('newTitle', this.titleBody);
  },
  methods: {
    setPost() {
      this.$emit('doPut', this.centroResultado);
    },
  },
}
</script>

<template>
<div class="card">
  <div class="card-body">
    <form id="form-centro-resultado" role="form" class="form-horizontal">
      <b-card no-body class="mb-1">
        <b-card-body>
          <div class="form-row form-group" role="group">
            <div class="col-sm-12 col-md-3">
              <div class="form-group">
                <label for="centro_resultado_id" class="col-form-label">Código</label>
                <div class="col">
                  <input disabled v-model="centroResultado.id" class="form-control text-right" type="text" placeholder="Gerado pelo sistema" id="centro_resultado_id">
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="form-group">
                <label for="centro_resultado_woner_id" class="col-form-label">Código pai</label>
                <div class="col">
                  <input v-model="centroResultado.woner_id" class="form-control text-right" type="text" placeholder="Código da conta pai" id="centro_resultado_woner_id">
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="form-group">
                <label for="centro_resultado_conta" class="col-form-label">Conta</label>
                <div class="col">
                  <input v-model="centroResultado.conta" class="form-control text-right" type="text" placeholder="Nº da conta" id="centro_resultado_conta">
                </div>
              </div>
            </div>
          </div>
          <div class="form-row form-group" role="group">
            <div class="col-sm-12 col-md-10">
              <div class="form-group">
                <label for="centro_resultado_identificacao" class="col-form-label">Nome do Centro de Resultado</label>
                  <div class="col">
                    <input v-model="centroResultado.identificacao" class="form-control" type="text" placeholder="Identificação do Centro de Resultado" id="centro_resultado_identificacao">
                  </div>
              </div>
            </div>
          </div>
          <div class="form-row form-group" role="group">
            <div class="col-sm-12 col-md-10">
              <div class="form-group">
                <div class="col">
                  <b-form-checkbox
                   id="tipo-pagamento-touch"
                   v-model="centroResultado.status"
                   name="touch"
                   value="1"
                   unchecked-value="0"
                  >
                      Ativo
                  </b-form-checkbox>
                </div>
              </div>
            </div>
          </div>
        </b-card-body>
      </b-card>
    </form>
  </div>
  <div class="card-body">
    <div class="col-md-12 mt-10">
        <button class="btn btn-light" @click="setPost">Gravar</button>
    </div>
  </div>
</div>
</template>