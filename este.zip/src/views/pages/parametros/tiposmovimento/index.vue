<script>
import appConfig from "@/app.config";
import { authEasyMethods, notificationMethods } from '@/state/helpers';
import Layout from '@/views/layouts/main';
import PageHeader from '@/components/page-header';
import List from "./list.vue";
import Insert from "./insert.vue";
import Edit from "./edit.vue";
import { http } from '../../../../helpers/easyindustriaapi/config';

export default {
  page: {
    title: 'Tipos de Movimentos (Estoque/Financeiro/Fiscal)',
    meta: [{ name: 'description', content: appConfig.description }]
  },
  components: { Layout, PageHeader, List, Insert, Edit },
  data() {
    return {
      items: [
        {
          text: "Dashboard",
          href: "/",
        },
        {
          text: "Parâmetros",
          href: "/",
          active: true,
        },
        {
          text: "Tipos Movimento",
          href: "/parametros/tiposmovimento",
          active: true,
        }
      ],
      tipoMovimento: undefined,
      tiposMovimento: [],
      titleBody: 'Tipos de Movimento',
      editando: false,
      inserindo: false,
    }
  },
  created() {
    this.currentUser    = JSON.parse(localStorage.getItem('user'));
    this.currentEmpresa = JSON.parse(localStorage.getItem('currentEmpresa'));
  },
  computed: {
    notification() {
      return this.$store ? this.$store.state.notification : null;
    },
    isHide() {
      return (!this.inserindo && !this.editando);
    },
  },
  mounted() {
    this.getData();
  },
  methods: {
    ...authEasyMethods,
    ...notificationMethods,
    makeToast(variant = null, message = 'Error generic') {
      this.counter++;
      this.$bvToast.toast(message, {
        title: `Notificação`,
        toaster: 'b-toaster-bottom-right',
        variant: variant,
        solid: true,
        appendToast: true
      });
    },
    changeHomeTitle(newTitle) {
      this.titleBody = newTitle;
    },
    onLoader() {
      if (document.getElementById("preloader").style.display === "none")
      {
        document.getElementById("preloader").style.display = "block";
        document.getElementById("status").style.display = "block";
      }
    },
    offLoader() {
      if (document.getElementById("preloader").style.display === "block")
      {
        setTimeout(function () {
          document.getElementById("preloader").style.display = "none";
          document.getElementById("status").style.display = "none";
        }, 2500);
      }
    },
    async getData() {
      this.onLoader();

      try {
        let response = await http.get('/tipomovimento?empresa_id='+this.currentEmpresa.id);

        if (response.status === 200) {
          this.tiposMovimento = response.data;
          setTimeout(() => {
            this.offLoader();
          }, 2000);
        } else {
          this.tiposMovimento = [];
          this.makeToast('danger', 'Erro ao carregar lista');
          this.offLoader();
        }
      } catch (error) {
        this.offLoader();

        if (error.response) {
          if (error.response.status === 404) {
            this.makeToast('danger', 'Destino URL não encontrado!');
          } else {
            this.makeToast('danger', error.response);
          }
        }
      }
    },
    insert() {
      this.inserindo = !this.inserindo;
    },
    edit(newTipoMovimento) {
      this.tipoMovimento = newTipoMovimento;
      this.editando = !this.editando;
    },
    async doPost(tipoMovimento) {
      this.onLoader();

      try {
        let response = await http.post('/tipomovimento?empresa_id='+this.currentEmpresa.id, tipoMovimento);
        if (response) {
          this.offLoader();
          if (response.status === 200) {
            this.getData();
            this.inserindo = false;
            this.makeToast('success', 'Registro incluído');
          }
        }
      } catch (error) {
        this.offLoader();
        if (error.response) {
          if (error.response.status === 404) {
            this.makeToast('danger', 'Destino URL não encontrado!');
          } else {
            this.makeToast('danger', error);
          }
        }
      }
    },
    async doPut(tipoMovimento) {
      this.onLoader();

      try {
        let response = await http.put('/tipomovimento/'+tipoMovimento.id+'?empresa_id='+this.currentEmpresa.id, tipoMovimento);
        if (response) {
          this.offLoader();
          if (response.status === 200) {
            this.makeToast('success', 'Registro alterado');
            this.getData();
            this.editando = false;
          }
        }
      } catch (error) {
        this.offLoader();
        if (error.response) {
          if (error.response.status === 404) {
            this.makeToast('danger', 'Destino URL não encontrado!');
          } else {
            this.makeToast('danger', error);
          }
        }
      }
    },
    async doDelete(tipoMovimento) {
      this.onLoader();

      try {
        let response = await http.delete('/tipomovimento/'+tipoMovimento.id+'?empresa_id='+this.currentEmpresa.id, tipoMovimento);
        if (response) {
          if (response.status === 200) {
            this.getData();
            this.offLoader();
            this.makeToast('warning', 'Registro excluído');
          }
        }
      } catch (error) {
        this.offLoader();
        if (error.response) {
          if (error.response.status === 404) {
            this.makeToast('danger', 'Destino URL não encontrado!');
          } else {
            this.makeToast('danger', error);
          }
        }
      }
    },
    back() {
      this.inserindo = false;
      this.editando  = false;
      this.titleBody = 'Listagem dos Tipos de Movimento';
    },
  },
}
</script>

<template>
<Layout>
  <PageHeader :title="titleBody" :items="items" />
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-body">
          <div class="row">
            <div class="col-sm-12 col-md-6"></div>
            <div class="col-sm-12 col-md-6 text-md-right">
              <button @click="insert()" v-if="isHide" type="button" class="btn btn-success">+ Incluir Tipo</button>
              <button @click="back()" v-if="!isHide" class="btn btn-secondary">Voltar</button>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <div v-if="!isHide" class="card-body">
          <Edit v-if="editando"
           @newTitle="changeHomeTitle"
           @doPut="doPut"
           :oldTipoMovimento="tipoMovimento"
          />
          <Insert v-if="inserindo"
           @newTitle="changeHomeTitle"
           @doPost="doPost"
          />
        </div>
        <List
         :currentEmpresa="currentEmpresa"
         :listTiposMovimento="tiposMovimento"
         :hide="isHide"
         @newTitle="changeHomeTitle"
         @edit="edit"
         @doDelete="doDelete"
        />
      </div>
    </div>
  </div>
</Layout>
</template>