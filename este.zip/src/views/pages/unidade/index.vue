<script>
import appConfig from "@/app.config";
import { authEasyMethods, notificationMethods } from '@/state/helpers';
import { http } from '../../../../helpers/easyindustriaapi/config';
import Layout from "@/views/layouts/main";
import PageHeader from "@/components/page-header";

export default {
    page: {
        title: 'Unidades de Medida',
        meta: [{ name: 'description', content: appConfig.description }]
    },
    components: { Layout, PageHeader },
    data() {
        return {
            
        }
    },
    computed: {
        notification() {
            return this.$store ? this.$store.state.notification : null;
        },
        isHide() {
            return (!this.inserindo && !this.editando);
        },
    },
    created() {
        this.currentUser = JSON.parse(localStorage.getItem('user'));
        this.currentEmpresa = JSON.parse(localStorage.getItem('currentEmpresa'));
    },
    methods: {
        ...authEasyMethods,
        ...notificationMethods,
        makeToast(variant = null, message = 'Error generic') {
            this.counter++;
            this.$bvToast.toast(message, {
                title: `Notificação`,
                toaster: 'b-toaster-bottom-right',
                variant: variant,
                solid: true,
                appendToast: true
            });
        },
        changeHomeTitle(newTitle) {
            this.titleBody = newTitle;
        },
        onLoader() {
            if (document.getElementById("preloader").style.display === "none") {
                document.getElementById("preloader").style.display = "block";
                document.getElementById("status").style.display = "block";
            }
        },
        offLoader() {
            if (document.getElementById("preloader").style.display === "block") {
                setTimeout(function () {
                    document.getElementById("preloader").style.display = "none";
                    document.getElementById("status").style.display = "none";
                }, 2500);
            }
        },
    }
}
</script>

<template>
    <Layout>
        <PageHeader :title="titleBody" :items="items" />
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-6"></div>
                            <div class="col-sm-12 col-md-6 text-md-right">
                                <button @click="insert()" v-if="isHide" type="button" class="btn btn-success">
                                    + Incluir Unidade
                                </button>
                                <button @click="back()" v-if="!isHide" class="btn btn-secondary">Voltar</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div v-if="!isHide" class="card-body">
                    </div>
                </div>
            </div>
        </div>
    </Layout>
</template>