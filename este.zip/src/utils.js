const utils = {
  install(Vue) {
    Vue.prototype.formatterCurrBR = (value) => {
      if (!parseFloat(value)) {
        return parseFloat(value).toFixed(2).replace(".",",")
      }
    
      return 'R$ ' + value.toFixed(2).replace(".",",")
    }
    Vue.prototype.formatterFloatBR = (value) => {
      if (!parseFloat(value)) {
        return parseFloat(value).toFixed(2).replace(".",",")
      }
    
      return value.toFixed(2).replace(".",",")
    }
    Vue.prototype.removeAccent = (value) => {   
      let str = value;
      str = str.replace(/[ÀÁÂÃÄÅ]/g,"A");
      str = str.replace(/[àáâãäå]/g,"a");
      str = str.replace(/[ÈÉÊË]/g,"E");
      return str;
    }
  }
}

export default utils