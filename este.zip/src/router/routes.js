import store from '@/state/store'

export default [
    {
        path: '/login',
        name: 'login',
        component: () => import('../views/pages/account/login'),
        meta: {
            beforeResolve(routeTo, routeFrom, next) {
                // If the user is already logged in
                if (store.getters['autheasy/loggedIn']) {
                    // Redirect to the home page instead
                    next({ name: 'home' })
                } else {
                    // Continue to the login page
                    next()
                }
            },
        },
    },
    {
        path: '/select-company',
        name: 'Select-company',
        meta: {
            authRequired: true
        },
        component: () => import('../views/pages/account/select-company'),
    },
    {
        path: '/userGetAll',
        name: 'userGetAll',
        component: () => import('../views/pages/account/getall')
    },
    {
        path: '/register',
        name: 'register',
        meta: {
            authRequired: true
        },
        component: () => import('../views/pages/account/register'),
    },
    {
        path: '/forgot-password',
        name: 'Forgot-password',
        component: () => import('../views/pages/account/forgot-password'),
        meta: {
            beforeResolve(routeTo, routeFrom, next) {
                // If the user is already logged in
                if (store.getters['autheasy/loggedIn']) {
					store.dispatch('autheasy/resetpassWord');
                    // Redirect to the home page instead
                    next({ name: 'home' })
                } else {
					store.dispatch('autheasy/resetpassWord');
                    // Continue to the login page
                    next()
                }
            },
        },
    },
    {
        path: '/logout',
        name: 'logout',
        meta: {
            authRequired: true,
            beforeResolve(routeTo, routeFrom, next) {
                if (process.env.VUE_APP_DEFAULT_AUTH === "firebase") {
                    store.dispatch('auth/logOut')
                } else {
                    if (process.env.VUE_APP_DEFAULT_AUTH === "easyindustria-api") {
						store.dispatch('autheasy/loGout')
					} else {
						store.dispatch('authfack/logout')
					}
                }
                const authRequiredOnPreviousRoute = routeFrom.matched.some(
                    (route) => route.push('/login')
                )
                // Navigate back to previous page, or home as a fallback
                next(authRequiredOnPreviousRoute ? { name: 'home' } : { ...routeFrom })
            },
        },
    },
    {
        path: '/',
        name: 'home',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/dashboard/index')
    },
    {
        path: '/cadastros/empresas',
        name: 'empresas',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/empresa/index')
    },
    {
        path: '/cadastros/pessoas',
        name: 'pessoas',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/pessoa/index')
    },
    {
        path: '/cadastros/produtos',
        name: 'produtos',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/produto/index')
    },
    {
        path: '/cadastros/localestoque',
        name: 'cadastros-localestoque',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/localestoque/index')
    },
    {
        path: '/financeiro/pedidos',
        name: 'compas',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/financeiro/pedidos/index')
    },
    {
        path: '/financeiro/bancos',
        name: 'bancos',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/financeiro/bancos/index')
    },
    {
        path: '/financeiro/agenciaBanc',
        name: 'agencia',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/financeiro/agenciaBanc/index')
    },
    
   
    {
        path: '/parametros/tiposmovimento',
        name: 'parametros-tiposmovimento',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/parametros/tiposmovimento/index')
    },
    {
        path: '/parametros/tipospagamento',
        name: 'parametros-tipospagamento',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/parametros/tipospagamento/index')
    },
    {
        path: '/parametros/centrocusto',
        name: 'parametros-centrocusto',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/parametros/centrocusto/index')
    },
    {
        path: '/parametros/centroresultado',
        name: 'parametros-centroresultado',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/parametros/centroresultado/index')
    },
    {
        path: '/parametros/historicopadrao',
        name: 'parametros-historicopadrao',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/parametros/historicopadrao/index')
    },
    {
        path: '/parametros/unidademed',
        name: 'parametros-unidademed',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/parametros/unidademed/index')
       

    },

    {
        path: '/parametros/grupos',
        name: 'parametros-grupos',
        meta: {
            authRequired: true,
        },
        component: () => import('../views/pages/parametros/grupos/index')
       

    }
   
]
