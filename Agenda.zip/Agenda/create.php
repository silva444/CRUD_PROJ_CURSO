<?php 
include_once("templates/header.php");
?>
       
  <div class="container">
       <?php include_once("templates/back_btn.html"); ?>
       <h1 id="main-title">Criar Contato</h1>
       <form id="create-form" action="<?= $BASE_URL ?>/config/process.php" method="POST">
       <input type="hidden" name="type" value="create"> <!-- hidden - oculto da pagina-->
       <!-- esse input vai guiar nosso projeto no process.php-->
       <div class="form-group">
              <label for="name">Nome do Contato:</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="digite o nome" required>

       </div>
       <div class="form-group">
              <label for="phone">Telefone do Contato:</label>
              <input type="text" class="form-control" id="phone" name="phone" placeholder="digite o telefone" required>

       </div>
       <div class="form-group">
              <label for="observations">Observações:</label>
              <textarea type="text" class="form-control" id="observations" name="observations" 
              placeholder="digite o algo" rows="3" ></textarea> <!--rows =3 , para gamhar uma altura 
           minima -->

       </div>
       <button id="bnt1" type="submit" class="btn btn-primary">Cadastrar</button>

       </form>
  </div>

<?php 
include_once("templates/footer.php");
?>