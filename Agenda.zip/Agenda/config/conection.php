<?php

$host="localhost";
$db="Agenda";
$user="root";
$pass="";

try {  // relembrar isto // revisar 

    $conn= new PDO("mysql:host=$host;dbname=$db",$user, $pass);

    //ATIVAR O MODO DE EROO ;

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
  // erro na conexão 

  $error= $e->getMessage(); // cosigo isolar o erro em uam varivel;

  echo "ERRO:".$error ;



}
?>