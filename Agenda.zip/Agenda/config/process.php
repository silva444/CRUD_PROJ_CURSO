<?php
session_start(); // pq vou ter msg por sessão;

include_once("conection.php");

include_once("url.php");



$data= $_POST;

if(!empty($data)){ // se os dados não estao vazios // modificaçõs no banco;
    print_r($data);

    // CRIAR CONTATO 
    if($data["type"] === "create") {
       // echo "CRIA OS DADOS";
        $name = $data["name"];
        $phone = $data["phone"];
        $observations = $data["observations"];

        $query = "INSERT INTO contacts (name,phone,observations) VALUES (:name,:phone,:observations)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":name",$name);
        $stmt->bindParam(":phone",$phone);
        $stmt->bindParam(":observations",$observations);

        try {  // relembrar isto // revisar 

            $stmt->execute();
            $_SESSION["msg"] = "Contato Criado com Sucesso ";
        
        } catch (PDOException $e) {
          // erro na conexão 
        
          $error= $e->getMessage(); // cosigo isolar o erro em uam varivel;
        
          echo "ERRO:".$error ;
        
        
        
        }

       
    }else if ($data["type"] === "edit"){
        $name = $data["name"];
        $phone = $data["phone"];
        $observations = $data["observations"];
        $id = $data["id"];

        $query = "UPDATE contacts 
                    SET  name = :name, phone = :phone, observations= :observations 
                    WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":name",$name);
        $stmt->bindParam(":phone",$phone);
        $stmt->bindParam(":observations",$observations);
        $stmt->bindParam(":id",$id);

        try {  // relembrar isto // revisar 

            $stmt->execute();
            $_SESSION["msg"] = "Contato Atualizado com Sucesso!";
        
        } catch (PDOException $e) {
          // erro na conexão 
        
          $error= $e->getMessage(); // cosigo isolar o erro em uam varivel;
        
          echo "ERRO:".$error ;
        
        
        
        }
        
    }else if($data["type"] === "delete") {
        $id = $data["id"];

        $query = "DELETE FROM contacts WHERE id = :id";
  
        $stmt = $conn->prepare($query);
  
        $stmt->bindParam(":id", $id);
        
        try {
  
          $stmt->execute();
          $_SESSION["msg"] = "Contato removido com sucesso!";
      
        } catch(PDOException $e) {
          // erro na conexão
          $error = $e->getMessage();
          echo "Erro: $error";
        }

    }

    //redirect home ;
    header("Location:".$BASE_URL."../index.php");

}else{ // seleção de dados

    // retorna o dado de um contato;
$id;

if(!empty($_GET)){ // GET NAO ESTA EMPTY, O GET TEM QUE ENVIAR ALGUMA COSIAS;
    $id = $_GET['id'];

}

if(!empty($id)){ // se id nao está vazio;
   $querry = "SELECT * FROM contacts WHERE id= :id";
   $stmt = $conn->prepare($querry);
   $stmt->bindParam(":id", $id);
   $stmt->execute();

   $contact = $stmt->fetch();

}else {
// retorna todos os contatos;
    $contacts = [];

    $querry = "SELECT * FROM contacts";


    $stmt = $conn->prepare($querry); // nao tem bind, pois nao tem parametros;
    $stmt->execute();

    $contacts = $stmt->fetchAll(); // pega todos os dados do bd;

}   


}

// fechar coneção ;

$conn = null;

?>